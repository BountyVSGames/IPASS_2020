var searchData=
[
  ['write',['write',['../classmatrix__part.html#a2a218481c377245fbf5fbd74c9cf467e',1,'matrix_part::write()'],['../classmatrix__pins__rgb.html#ad5dd647ecfb37502f95c9255072ac516',1,'matrix_pins_rgb::write()']]],
  ['write_5fimplementation',['write_implementation',['../classmatrix.html#a81034d9b2d1b26438be9861e837a962b',1,'matrix']]]
];
