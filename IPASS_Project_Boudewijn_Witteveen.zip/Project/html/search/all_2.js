var searchData=
[
  ['b',['b',['../classmatrix__pins__rgb.html#ab720e7705783585a446a2bb47b6ad5d8',1,'matrix_pins_rgb']]],
  ['bmptk_5ffixed_5fsize_5fstack_2ec',['bmptk_fixed_size_stack.c',['../bmptk__fixed__size__stack_8c.html',1,'']]],
  ['bottom',['bottom',['../classmatrix.html#a8a571e0a29b41e59f71d851fa3dfc227',1,'matrix']]],
  ['box',['box',['../enums_8hpp.html#aa2b983d3f5fee7f17796e5ef5040d787a34be958a921e43d813a2075297d8e862',1,'enums.hpp']]]
];
