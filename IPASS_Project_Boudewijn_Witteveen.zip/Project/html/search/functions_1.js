var searchData=
[
  ['clear',['clear',['../classmatrix.html#a58f399a7e96f56100491d6d8ad235f68',1,'matrix']]]
];
