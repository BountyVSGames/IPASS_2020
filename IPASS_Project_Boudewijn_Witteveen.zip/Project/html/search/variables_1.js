var searchData=
[
  ['b',['b',['../classmatrix__pins__rgb.html#ab720e7705783585a446a2bb47b6ad5d8',1,'matrix_pins_rgb']]],
  ['bottom',['bottom',['../classmatrix.html#a8a571e0a29b41e59f71d851fa3dfc227',1,'matrix']]]
];
