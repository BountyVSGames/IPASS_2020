var searchData=
[
  ['showframe',['showFrame',['../classmatrix.html#a78bca859b321539d1749b0d3ef8c11c5',1,'matrix']]]
];
