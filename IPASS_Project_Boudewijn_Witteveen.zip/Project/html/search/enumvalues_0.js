var searchData=
[
  ['box',['box',['../enums_8hpp.html#aa2b983d3f5fee7f17796e5ef5040d787a34be958a921e43d813a2075297d8e862',1,'enums.hpp']]]
];
