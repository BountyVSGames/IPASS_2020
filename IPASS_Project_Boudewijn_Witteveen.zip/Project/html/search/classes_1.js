var searchData=
[
  ['matrix',['matrix',['../classmatrix.html',1,'']]],
  ['matrix_5fpart',['matrix_part',['../classmatrix__part.html',1,'']]],
  ['matrix_5fpins_5frgb',['matrix_pins_rgb',['../classmatrix__pins__rgb.html',1,'']]],
  ['matrix_5fport',['matrix_port',['../classmatrix__port.html',1,'']]]
];
