var searchData=
[
  ['update',['update',['../classtetrisObjectDrawable.html#a3c8d207623221bd17246d51c13dc3eb4',1,'tetrisObjectDrawable']]],
  ['update_5fall',['update_all',['../classgraphics__drawer.html#ac85a6dc3e0ef97fc793f91862e794c47',1,'graphics_drawer']]]
];
