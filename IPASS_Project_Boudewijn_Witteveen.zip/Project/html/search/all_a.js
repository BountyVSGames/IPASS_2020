var searchData=
[
  ['number_5fof_5fpins',['number_of_pins',['../classmatrix__pins__rgb.html#adcb58fe638967b23f72cc505d8bd8019',1,'matrix_pins_rgb']]]
];
