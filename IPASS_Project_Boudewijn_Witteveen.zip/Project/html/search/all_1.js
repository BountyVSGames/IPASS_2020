var searchData=
[
  ['active',['active',['../classtetrisObjectDrawable.html#a0514772753a8926f5dcbf3d5384d486a',1,'tetrisObjectDrawable']]],
  ['address',['address',['../classmatrix__port.html#a9c216b02627d4b595dfb5a4f64547df2',1,'matrix_port']]]
];
