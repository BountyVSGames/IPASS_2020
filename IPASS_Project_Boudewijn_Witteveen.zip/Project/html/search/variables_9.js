var searchData=
[
  ['top',['top',['../classmatrix.html#ada4fc9c5734e5c7b27fe525bae27be7c',1,'matrix']]],
  ['type',['type',['../classtetrisObjectDrawable.html#a0166b001667649c81bc968b4094ee557',1,'tetrisObjectDrawable']]]
];
