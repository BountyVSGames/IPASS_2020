var searchData=
[
  ['tetristypes',['tetrisTypes',['../enums_8hpp.html#aa2b983d3f5fee7f17796e5ef5040d787',1,'enums.hpp']]]
];
