var searchData=
[
  ['flush',['flush',['../classmatrix.html#a867830c5b26171d0b031aadeb8ad1eee',1,'matrix::flush()'],['../classmatrix__pins__rgb.html#a79174576ae97424811a431bfec08c72c',1,'matrix_pins_rgb::flush()']]]
];
