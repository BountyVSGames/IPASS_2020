var searchData=
[
  ['piramide',['piramide',['../enums_8hpp.html#aa2b983d3f5fee7f17796e5ef5040d787a26d4d3e915c2fb3a22a3a41acb67ebd8',1,'enums.hpp']]]
];
