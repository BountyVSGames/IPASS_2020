var searchData=
[
  ['g',['g',['../classmatrix__pins__rgb.html#ad6fb34fc8a4c10d0a39631d9b5894330',1,'matrix_pins_rgb']]]
];
