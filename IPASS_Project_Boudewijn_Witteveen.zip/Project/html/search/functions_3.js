var searchData=
[
  ['emit',['emit',['../classmatrix__part.html#ae4c419aa81e5895dde34bfecaccd7eba',1,'matrix_part']]]
];
