var searchData=
[
  ['latch',['latch',['../classmatrix__port.html#a98a55b7d0a8ce1ba4c03a82b7a25c0da',1,'matrix_port']]]
];
